import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { query } = body

    if (!query) {
      return NextResponse.json(
        { success: false, error: 'Query is required' },
        { status: 400 }
      )
    }

    // Initialize ZAI SDK
    const zai = await ZAI.create()

    // Search for fashion trends
    const results = await zai.functions.invoke('web_search', {
      query: query,
      num: 12
    })

    if (!Array.isArray(results)) {
      throw new Error('Invalid search results')
    }

    return NextResponse.json({
      success: true,
      results: results
    })
  } catch (error) {
    console.error('Trends search error:', error)
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to search trends'
      },
      { status: 500 }
    )
  }
}
