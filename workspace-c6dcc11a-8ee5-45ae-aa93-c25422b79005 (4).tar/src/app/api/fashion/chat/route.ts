import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { message, history = [], preferences } = body

    if (!message) {
      return NextResponse.json(
        { success: false, error: 'Message is required' },
        { status: 400 }
      )
    }

    // Initialize ZAI SDK
    const zai = await ZAI.create()

    // Build system prompt with preferences context
    let preferencesContext = ''
    if (preferences) {
      const prefs = Object.entries(preferences)
        .filter(([_, value]) => value && value.trim())
        .map(([key, value]) => `${key}: ${value}`)
        .join('\n')

      if (prefs) {
        preferencesContext = `\n\nUser Preferences:\n${prefs}`
      }
    }

    const systemPrompt = `You are a professional AI Fashion Advisor with expertise in:
- Personal styling and outfit recommendations
- Current fashion trends and timeless style advice
- Color theory and wardrobe coordination
- Body type analysis and flattering clothing choices
- Seasonal fashion and occasion-appropriate dressing
- Sustainable fashion and wardrobe building

Provide helpful, specific, and practical fashion advice. Ask clarifying questions when needed to give better recommendations. Be encouraging and constructive. Always consider the user's preferences when available.${preferencesContext}`

    // Build conversation history
    const messages = [
      {
        role: 'assistant',
        content: systemPrompt
      },
      ...history.map((msg: any) => ({
        role: msg.role === 'user' ? 'user' : 'assistant',
        content: msg.content
      })),
      {
        role: 'user',
        content: message
      }
    ]

    // Get response from LLM
    const response = await zai.chat.completions.create({
      messages: messages,
      thinking: { type: 'disabled' }
    })

    const aiResponse = response.choices[0]?.message?.content

    if (!aiResponse) {
      throw new Error('No response generated')
    }

    return NextResponse.json({
      success: true,
      response: aiResponse
    })
  } catch (error) {
    console.error('Chat error:', error)
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to get response'
      },
      { status: 500 }
    )
  }
}
