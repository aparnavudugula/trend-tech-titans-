'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { toast } from '@/hooks/use-toast'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  User, 
  Lock, 
  Mail, 
  Eye, 
  EyeOff,
  Sparkles,
  ArrowRight,
  UserPlus,
  CheckCircle2,
  X
} from 'lucide-react'

export default function SignupPage() {
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  })
  const [errors, setErrors] = useState({
    password: '',
    confirmPassword: ''
  })

  const gradients = [
    'from-pink-400 via-rose-500 to-orange-500',
    'from-purple-400 via-pink-500 to-rose-500',
    'from-orange-400 via-pink-500 to-purple-500',
    'from-green-400 via-teal-500 to-blue-500',
    'from-indigo-400 via-purple-500 to-pink-500',
    'from-blue-400 via-cyan-500 to-teal-500'
  ]

  const [bgColor, setBgColor] = useState(0)

  const containerVariants = {
    hidden: { opacity: 0 },
    show: { opacity: 1 },
  }

  const cardVariants = {
    hidden: { 
      opacity: 0, 
      y: 50,
      scale: 0.9,
      rotate: 2
    },
    show: { 
      opacity: 1, 
      y: 0,
      scale: 1,
      rotate: 0,
      transition: {
        duration: 0.6,
        ease: [0.43, 0.13, 0.23, 1]
      }
    }
  }

  const stepVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 50 : -50,
      opacity: 0,
      scale: 0.9
    }),
    center: {
      x: 0,
      opacity: 1,
      scale: 1,
      transition: {
        duration: 0.4,
        ease: [0.43, 0.13, 0.23, 1]
      }
    },
    exit: (direction: number) => ({
      x: direction < 0 ? 50 : -50,
      opacity: 0,
      scale: 0.9
    })
  }

  const validatePassword = (password: string) => {
    if (password.length < 8) {
      return 'Password must be at least 8 characters'
    }
    if (!/(?=.*[a-z])(?=.*[A-Z])/.test(password)) {
      return 'Password must contain uppercase and lowercase letters'
    }
    if (!/(?=.*\d)/.test(password)) {
      return 'Password must contain at least one number'
    }
    return ''
  }

  const handleNext = () => {
    if (step === 1) {
      if (!formData.name.trim()) {
        toast({
          title: 'Name Required',
          description: 'Please enter your name.',
          variant: 'destructive',
        })
        return
      }
      if (!formData.email.trim() || !formData.email.includes('@')) {
        toast({
          title: 'Invalid Email',
          description: 'Please enter a valid email address.',
          variant: 'destructive',
        })
        return
      }
    }

    if (step === 2) {
      const passwordError = validatePassword(formData.password)
      if (passwordError) {
        setErrors({ ...errors, password: passwordError })
        return
      }
      if (formData.password !== formData.confirmPassword) {
        setErrors({ ...errors, confirmPassword: 'Passwords do not match' })
        return
      }
      setErrors({ password: '', confirmPassword: '' })
    }

    if (step < 3) {
      setStep(step + 1)
    }
  }

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    setTimeout(() => {
      setIsLoading(false)
      toast({
        title: 'Account Created!',
        description: 'Welcome to FashionAI! Your account has been created successfully.',
        variant: 'default',
      })
      window.location.href = '/login'
    }, 1500)
  }

  return (
    <motion.div
      initial="hidden"
      animate="show"
      variants={containerVariants}
      transition={{ duration: 0.6 }}
      className="min-h-screen flex items-center justify-center overflow-hidden relative py-8"
    >
      {/* Animated Background */}
      <div className="absolute inset-0 -z-10">
        <motion.div
          className={`w-full h-full bg-gradient-to-br ${gradients[bgColor]} transition-all duration-[10000ms] ease-in-out`}
          animate={{
            opacity: [0.6, 0.8, 0.6],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        <div className="absolute inset-0 bg-slate-50/95 backdrop-blur-sm" />
      </div>

      {/* Floating Elements */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[...Array(8)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute bg-white/10 rounded-full blur-3xl"
            style={{
              width: Math.random() * 150 + 80,
              height: Math.random() * 150 + 80,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`
            }}
            animate={{
              y: [0, -40, 0],
              x: [0, 30, 0],
              scale: [1, 1.3, 1],
            }}
            transition={{
              duration: 5 + i,
              repeat: Infinity,
              ease: "easeInOut",
              delay: i * 0.4
            }}
          />
        ))}
      </div>

      <motion.div
        variants={cardVariants}
        initial="hidden"
        animate="show"
        className="relative z-10 w-full max-w-md px-4"
      >
        <Card className="border-slate-200 shadow-2xl backdrop-blur-xl bg-white/95">
          <CardHeader className="space-y-2 text-center pb-6">
            <motion.div
              animate={{ 
                rotate: [0, -5, 5, 0],
                scale: [1, 1.15, 1]
              }}
              transition={{ 
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="w-16 h-16 rounded-2xl bg-gradient-to-br from-pink-500 to-purple-600 flex items-center justify-center mx-auto shadow-xl"
            >
              <UserPlus className="w-8 h-8 text-white" />
            </motion.div>
            <CardTitle className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-600 to-purple-700">
              Create Account
            </CardTitle>
            <CardDescription className="text-base text-slate-600">
              Join FashionAI for personalized style recommendations
            </CardDescription>
          </CardHeader>

          <CardContent>
            {/* Step Indicator */}
            <div className="flex items-center justify-center gap-2 mb-6">
              {[1, 2, 3].map((s) => (
                <motion.div
                  key={s}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ duration: 0.3, delay: s * 0.1 }}
                  className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    step >= s 
                      ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white' 
                      : 'bg-slate-200 text-slate-500'
                  }`}
                >
                  <span className="text-sm font-bold">{s}</span>
                </motion.div>
              ))}
              {[1, 2].map((s) => (
                <motion.div
                  key={s}
                  initial={{ scaleX: 0 }}
                  animate={{ scaleX: 1 }}
                  transition={{ duration: 0.3, delay: s * 0.15 }}
                  className={`h-1 w-12 ${
                    step > s ? 'bg-gradient-to-r from-pink-500 to-purple-600' : 'bg-slate-200'
                  }`}
                />
              ))}
            </div>

            <AnimatePresence mode="wait" custom={step}>
              <motion.div
                key={step}
                custom={step}
                variants={stepVariants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.4 }}
                className="space-y-5"
              >
                {step === 1 && (
                  <div className="space-y-4">
                    <motion.div className="space-y-2">
                      <label className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                        <User className="w-4 h-4" />
                        Full Name
                      </label>
                      <Input
                        type="text"
                        placeholder="Enter your name"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="h-12 border-slate-300 focus:border-purple-500"
                        required
                      />
                    </motion.div>

                    <motion.div className="space-y-2">
                      <label className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                        <Mail className="w-4 h-4" />
                        Email Address
                      </label>
                      <Input
                        type="email"
                        placeholder="you@example.com"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="h-12 border-slate-300 focus:border-purple-500"
                        required
                      />
                    </motion.div>
                  </div>
                )}

                {step === 2 && (
                  <div className="space-y-4">
                    <motion.div className="space-y-2">
                      <label className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                        <Lock className="w-4 h-4" />
                        Password
                      </label>
                      <div className="relative">
                        <Input
                          type={showPassword ? "text" : "password"}
                          placeholder="Create a password"
                          value={formData.password}
                          onChange={(e) => {
                            setFormData({ ...formData, password: e.target.value })
                            setErrors({ ...errors, password: validatePassword(e.target.value) })
                          }}
                          className={`pl-11 pr-11 h-12 border-slate-300 focus:border-purple-500 ${
                            errors.password ? 'border-red-500' : ''
                          }`}
                          required
                        />
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                        <motion.button
                          type="button"
                          whileTap={{ scale: 0.9 }}
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors"
                        >
                          {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                        </motion.button>
                      </div>
                      {errors.password && (
                        <motion.p 
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="text-xs text-red-600 mt-1"
                        >
                          {errors.password}
                        </motion.p>
                      )}
                    </motion.div>

                    <motion.div className="space-y-2">
                      <label className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4" />
                        Confirm Password
                      </label>
                      <div className="relative">
                        <Input
                          type={showConfirmPassword ? "text" : "password"}
                          placeholder="Confirm your password"
                          value={formData.confirmPassword}
                          onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                          className={`pl-11 pr-11 h-12 border-slate-300 focus:border-purple-500 ${
                            errors.confirmPassword ? 'border-red-500' : ''
                          }`}
                          required
                        />
                        <CheckCircle2 className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                        <motion.button
                          type="button"
                          whileTap={{ scale: 0.9 }}
                          onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors"
                        >
                          {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                        </motion.button>
                      </div>
                      {errors.confirmPassword && (
                        <motion.p 
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="text-xs text-red-600 mt-1"
                        >
                          {errors.confirmPassword}
                        </motion.p>
                      )}
                    </motion.div>

                    <div className="space-y-2 text-xs text-slate-500">
                      <p className="flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3 text-green-500" />
                        At least 8 characters
                      </p>
                      <p className="flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3 text-green-500" />
                        Uppercase & lowercase
                      </p>
                      <p className="flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3 text-green-500" />
                        At least one number
                      </p>
                    </div>
                  </div>
                )}

                {step === 3 && (
                  <div className="space-y-6 text-center">
                    <motion.div
                      animate={{ scale: [1, 1.05, 1] }}
                      transition={{ duration: 2, repeat: Infinity }}
                    >
                      <UserPlus className="w-20 h-20 text-slate-400 mx-auto" />
                    </motion.div>
                    <div className="bg-slate-50 rounded-xl p-6 space-y-3">
                      <p className="text-sm text-slate-600">
                        <span className="font-semibold">Name:</span> {formData.name}
                      </p>
                      <p className="text-sm text-slate-600">
                        <span className="font-semibold">Email:</span> {formData.email}
                      </p>
                      <p className="text-sm text-slate-600">
                        <span className="font-semibold">Password:</span> {'•'.repeat(8)}
                      </p>
                    </div>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>

            {/* Navigation Buttons */}
            <div className="flex gap-3 mt-6">
              {step > 1 && (
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    type="button"
                    onClick={handleBack}
                    variant="outline"
                    className="flex-1 h-12 border-slate-300"
                  >
                    Back
                  </Button>
                </motion.div>
              )}

              {step < 3 ? (
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    type="button"
                    onClick={handleNext}
                    className="flex-1 bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 h-12 shadow-lg"
                  >
                    {step === 2 ? 'Review' : 'Next'}
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </motion.div>
              ) : (
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    type="button"
                    onClick={handleSubmit}
                    disabled={isLoading}
                    className="flex-1 bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 h-12 shadow-lg"
                  >
                    {isLoading ? (
                      <>
                        <motion.div
                          animate={{ rotate: 360 }}
                          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                        >
                          <Sparkles className="w-5 h-5 mr-2" />
                        </motion.div>
                        Creating Account...
                      </>
                    ) : (
                      <>
                        Create Account
                        <Sparkles className="w-5 h-5 ml-2" />
                      </>
                    )}
                  </Button>
                </motion.div>
              )}
            </div>

            <div className="relative mt-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-200" />
              </div>
              <span className="relative bg-white px-3 text-sm text-slate-500 font-medium">
                Or continue with
              </span>
            </div>

            <div className="grid grid-cols-3 gap-3 mt-6">
              {['Google', 'Apple', 'GitHub'].map((provider, idx) => (
                <motion.button
                  key={idx}
                  type="button"
                  whileHover={{ scale: 1.05, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                  className="flex items-center justify-center gap-2 px-4 py-3 border-2 border-slate-200 rounded-xl hover:border-slate-400 hover:bg-slate-50 transition-all bg-white"
                >
                  <div className="w-5 h-5 rounded-full bg-gradient-to-br from-pink-100 to-purple-100" />
                  <span className="text-sm font-medium text-slate-700">{provider}</span>
                </motion.button>
              ))}
            </div>

            <p className="text-center text-sm text-slate-600 mt-6">
              Already have an account?{' '}
              <Link href="/login" className="text-purple-600 hover:text-purple-700 font-semibold transition-colors">
                Sign in
              </Link>
            </p>
          </CardContent>
        </Card>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-6 text-center"
        >
          <Link 
            href="/"
            className="inline-flex items-center gap-2 px-4 py-2 text-slate-600 hover:text-slate-900 transition-colors"
          >
            <ArrowRight className="w-4 h-4 rotate-180" />
            <span className="font-medium">Back to Home</span>
          </Link>
        </motion.div>
      </motion.div>
    </motion.div>
  )
}
