'use client'

import { useState, useEffect, useRef } from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { toast } from '@/hooks/use-toast'
import { motion } from 'framer-motion'
import { 
  User, Sparkles, Image as ImageIcon, MessageSquare, TrendingUp, Settings, Upload, Loader2, 
  CheckCircle2, Palette, Shirt, Clock, Star, ArrowRight, Download, Share2, Heart, Zap, Shield, 
  Droplets, Layers, ShoppingBag, Eye, ChevronRight 
} from 'lucide-react'

interface OutfitSuggestion {
  id: number
  title: string
  style: string
  colors: string
  occasion: string
  description: string
}

export default function FashionAIPlatform() {
  // Tab navigation
  const [activeTab, setActiveTab] = useState('outfit-analyzer')

  // Analysis states
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysisResult, setAnalysisResult] = useState<string | null>(null)

  // Generation states
  const [isGenerating, setIsGenerating] = useState(false)
  const [analysisResult, setAnalysisResult] = useState<string | null>(null)

  // Chat states
  const [chatMessages, setChatMessages] = useState<{ role: 'user' | 'assistant'; content: string }[]>([
    { role: 'assistant', content: 'Welcome! I\'m your AI Fashion Stylist. I can help you with:\n• Outfit recommendations and styling advice\n• Color coordination tips\n• Trend insights and seasonal looks\n• Wardrobe optimization\n• Occasion-specific suggestions\n\nHow can I assist you today?' }
  ])
  const [chatInput, setChatInput] = useState('')

  // Trend and suggestion states
  const [isSearchingTrends, setIsSearchingTrends] = useState(false)
  const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(false)
  const [trends, setTrends] = useState<any[]>([])
  const [outfitSuggestions, setOutfitSuggestions] = useState<OutfitSuggestion[]>([])

  // User preferences
  const [preferences, setPreferences] = useState({
    style: '', size: '', colors: '', occasions: '', seasons: ''
  })

  // UI state
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [bgColor, setBgColor] = useState(0)
  const gradients = [
    'from-purple-400 via-pink-500 to-rose-500',
    'from-blue-400 via-cyan-500 to-teal-500',
    'from-orange-400 via-pink-500 to-purple-500',
    'from-green-400 via-teal-500 to-blue-500',
    'from-pink-400 via-rose-500 to-orange-500',
    'from-indigo-400 via-purple-500 to-pink-500'
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setBgColor(prev => (prev + 1) % gradients.length)
    }, 10000)
    return () => clearInterval(interval)
  }, [])

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    console.log('File selected:', file)
    if (!file) {
      toast({
        title: 'No File Selected',
        description: 'Please select an image to upload',
        variant: 'destructive'
      })
      return
    }

    console.log('Starting analysis for:', file.name, file.size)
    setIsAnalyzing(true)
    try {
      const formData = new FormData()
      formData.append('image', file)

      console.log('Sending to API...')
      const response = await fetch('/api/fashion/analyze', {
        method: 'POST',
        body: formData
      })

      console.log('API response status:', response.status)
      const data = await response.json()
      console.log('API data:', data)
      if (data.success) {
        setAnalysisResult(data.analysis)
        // Reset file input
        if (fileInputRef.current) {
          fileInputRef.current.value = ''
        }
        toast({
          title: 'Analysis Complete',
          description: 'Your outfit has been analyzed!',
          variant: 'default'
        })
      } else {
        throw new Error(data.error || 'Analysis failed')
      }
    } catch (error) {
      console.error('Analysis error:', error)
      toast({
        title: 'Analysis Failed',
        description: 'Failed to analyze outfit. Please try again.',
        variant: 'destructive'
      })
    } finally {
      setIsAnalyzing(false)
    }
  }

  const handleSendMessage = async () => {
    if (!chatInput.trim()) return

    const userMessage = chatInput.trim()
    setChatMessages(prev => [...prev, { role: 'user', content: userMessage }])
    setChatInput('')

    try {
      const response = await fetch('/api/fashion/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          message: userMessage,
          history: chatMessages.slice(1),
          preferences 
        })
      })

      const data = await response.json()
      if (data.success) {
        setChatMessages(prev => [...prev, { role: 'assistant', content: data.response }])
      } else {
        throw new Error(data.error || 'Chat failed')
      }
    } catch (error) {
      console.error('Chat error:', error)
      setChatMessages(prev => [...prev, { role: 'assistant', content: 'Sorry, I encountered an error. Please try again.' }])
    }
  }

  const handleGenerateOutfit = async () => {
    const prompt = `${preferences.style ? `Style: ${preferences.style}` : ''} ${preferences.seasons ? `Season: ${preferences.seasons}` : ''} ${preferences.occasions ? `Occasion: ${preferences.occasions}` : ''} ${preferences.colors ? `Colors: ${preferences.colors}` : ''} fashionable outfit`.trim()

    if (!prompt) {
      toast({
        title: 'Missing Information',
        description: 'Please provide some preferences first.',
        variant: 'destructive'
      })
      return
    }

    setIsGenerating(true)
    try {
      const response = await fetch('/api/fashion/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt })
      })

      const data = await response.json()
      if (data.success) {
        setGeneratedImage(data.imageUrl)
        toast({
          title: 'Outfit Generated',
          description: 'Your new outfit look has been created!',
          variant: 'default'
        })
      } else {
        throw new Error(data.error || 'Generation failed')
      }
    } catch (error) {
      console.error('Generation error:', error)
      toast({
        title: 'Generation Failed',
        description: 'Failed to generate outfit. Please try again.',
        variant: 'destructive'
      })
    } finally {
      setIsGenerating(false)
    }
  }

  const handleSearchTrends = async (category?: string) => {
    setIsSearchingTrends(true)
    try {
      const query = category ? `fashion trends ${category} ${new Date().getFullYear()}` : `fashion trends ${new Date().getFullYear()}`
      
      const response = await fetch('/api/fashion/trends', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query })
      })

      const data = await response.json()
      if (data.success) {
        setTrends(data.results)
        toast({
          title: 'Trends Found',
          description: 'Latest fashion trends loaded successfully!',
          variant: 'default'
        })
      } else {
        throw new Error(data.error || 'Search failed')
      }
    } catch (error) {
      console.error('Trends search error:', error)
      toast({
        title: 'Search Failed',
        description: 'Failed to load fashion trends.',
        variant: 'destructive'
      })
    } finally {
      setIsSearchingTrends(false)
    }
  }

  const handleGenerateStyleSuggestions = async () => {
    setIsLoadingSuggestions(true)
    try {
      const prompt = `professional fashion outfit suggestions ${preferences.style || ''} ${preferences.seasons || ''} ${preferences.occasions || ''}`.trim()
      
      const response = await fetch('/api/fashion/generate-suggestions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, preferences })
      })

      const data = await response.json()
      if (data.success) {
        setOutfitSuggestions(data.suggestions)
        toast({
          title: 'Suggestions Generated',
          description: 'New style suggestions have been created!',
          variant: 'default'
        })
      } else {
        throw new Error(data.error || 'Generation failed')
      }
    } catch (error) {
      console.error('Suggestions error:', error)
      toast({
        title: 'Generation Failed',
        description: 'Failed to generate suggestions.',
        variant: 'destructive'
      })
    } finally {
      setIsLoadingSuggestions(false)
    }
  }

  return (
    <motion.div
      initial="hidden"
      animate="show"
      className="min-h-screen flex flex flex-col overflow-hidden"
    >
      <div className="fixed inset-0 -z-10">
        <motion.div
          className={`w-full h-full bg-gradient-to-br ${gradients[bgColor]} transition-all duration-[10000ms] ease-in-out`}
          animate={{ opacity: [0.7, 1, 0.7] }}
          transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
        />
        <div className="absolute inset-0 bg-slate-50/90 backdrop-blur-sm" />
      </div>

      {/* Floating Elements */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute bg-white/10 rounded-full blur-3xl"
            style={{
              width: Math.random() * 200 + 100,
              height: Math.random() * 200 + 100,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`
            }}
            animate={{
              y: [0, -40, 0],
              x: [0, 30, 0],
              scale: [1, 1.3, 1],
              transition: {
                duration: 5 + i,
                repeat: Infinity,
                ease: "easeInOut",
                delay: i * 0.5
              }
            }}
          />
        ))}
      </div>

      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-md shadow-lg sticky top-0 z-50">
        <div className="container mx-auto px-4 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              className="flex items-center gap-4"
            >
              <motion.div
                whileHover={{ scale: 1.1, rotate: 5 }}
                whileTap={{ scale: 0.95 }}
                className="w-12 h-12 rounded-xl bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center shadow-xl"
              >
                <Sparkles className="w-6 h-6 text-white" />
              </motion.div>
              <div>
                <h1 className="text-2xl font-bold tracking-tight text-slate-900">FashionAI</h1>
                <p className="text-sm text-slate-500 font-medium">Professional Style Advisor</p>
              </div>
            </motion.div>
            
            <div className="flex items-center gap-4">
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="hidden md:flex items-center gap-4"
              >
                <Badge variant="outline" className="gap-2 px-3 py-1">
                  <Zap className="w-3 h-3" />
                  <span className="text-xs font-semibold">AI-Powered</span>
                </Badge>
                <Badge variant="outline" className="gap-2 px-3 py-1">
                  <Shield className="w-3 h-3" />
                  <span className="text-xs font-semibold">Privacy First</span>
                </Badge>
              </motion.div>
              
              <div className="flex items-center gap-2">
                <motion.a
                  href="/login"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="flex items-center gap-2 px-4 py-2 bg-slate-900 text-white rounded-lg hover:bg-slate-800 transition-colors"
                >
                  <User className="w-4 h-4" />
                  <span className="hidden sm:inline font-medium">Sign In</span>
                </motion.a>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 lg:px-8 py-8 overflow-hidden">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-8"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-slate-900 via-purple-900 to-pink-900 mb-4">
            Your Personal AI Fashion Consultant
          </h2>
          <motion.p 
            className="text-lg text-slate-600 max-w-2xl mx-auto"
            animate={{ opacity: [0.7, 1, 0.7] }}
            transition={{ duration: 3, repeat: Infinity }}
          >
            Get personalized outfit recommendations, expert styling advice, color coordination, and real-time trend insights
          </motion.p>
        </motion.div>

        <Tabs value={activeTab} onValueChange={(val) => {
          setActiveTab(val || 'outfit-analyzer')
        }} className="w-full">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <TabsList className="grid w-full grid-cols-6 mb-8 bg-white/90 backdrop-blur-sm shadow-lg h-14 overflow-x-auto border border-slate-200">
              {[
                { value: 'outfit-analyzer', icon: ImageIcon, label: 'Analyzer' },
                { value: 'style-suggestions', icon: Layers, label: 'Suggestions' },
                { value: 'color-palette', icon: Palette, label: 'Colors' },
                { value: 'style-advisor', icon: MessageSquare, label: 'Advisor' },
                { value: 'trend-explorer', icon: TrendingUp, label: 'Trends' },
                { value: 'preferences', icon: Settings, label: 'Settings' }
              ].map((tab) => (
                <TabsTrigger key={tab.value} value={tab.value} className="flex items-center gap-2 data-[state=active]:bg-slate-900 data-[state=active]:text-white">
                  <tab.icon className="w-4 h-4" />
                  <span className="hidden sm:inline font-medium">{tab.label}</span>
                </TabsTrigger>
              ))}
            </TabsList>
          </motion.div>

          {/* Outfit Analyzer Tab */}
          <TabsContent value="outfit-analyzer">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
              <div className="grid lg:grid-cols-2 gap-6">
                <Card className="border-slate-200 shadow-xl">
                  <CardHeader className="space-y-1">
                    <CardTitle className="flex items-center gap-2 text-xl">
                      <div className="p-2 bg-slate-100 rounded-lg">
                        <ImageIcon className="w-5 h-5 text-slate-700" />
                      </div>
                      Outfit Analysis
                    </CardTitle>
                    <CardDescription className="text-base">
                      Upload your outfit photo for instant AI-powered style analysis
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="border-2 border-dashed border-slate-300 rounded-xl p-12 flex flex-col items-center justify-center gap-6 bg-slate-50/50 min-h-[400px]">
                      <motion.div
                        whileHover={{ scale: 1.02 }}
                        onClick={() => fileInputRef.current?.click()}
                        className="flex flex-col items-center gap-4 p-8 bg-white rounded-2xl shadow-xl cursor-pointer border-2 border-slate-200 w-full max-w-md"
                      >
                        <motion.div
                          whileHover={{ rotate: 5 }}
                          className="w-24 h-24 rounded-full bg-slate-100 flex items-center justify-center"
                        >
                          <Upload className="w-12 h-12 text-slate-400" />
                        </motion.div>
                        <div className="text-center space-y-2">
                          <p className="font-semibold text-lg text-slate-700">Upload Your Outfit Photo</p>
                          <p className="text-slate-500">Click or drag & drop to upload</p>
                          <p className="text-sm text-slate-400">Supports JPG, PNG, WEBP</p>
                        </div>
                        <input
                          ref={fileInputRef}
                          key="file-upload"
                          type="file"
                          accept="image/*"
                          onChange={handleImageUpload}
                          disabled={isAnalyzing}
                          className="hidden"
                        />
                      </motion.div>
                    </div>

                    <div className="mt-6 flex items-start gap-3 px-4 py-3 bg-blue-50 rounded-lg border border-blue-100">
                      <Star className="w-5 h-5 text-blue-600 mt-0.5" />
                      <div>
                        <p className="font-semibold text-sm text-blue-900">Pro Tips</p>
                        <p className="text-sm text-blue-700">• Use good lighting for best results</p>
                        <p className="text-sm text-blue-700">• Stand back to show full outfit</p>
                        <p className="text-sm text-blue-700">• Show clear, high-quality image</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-slate-200 shadow-xl">
                  <CardHeader className="space-y-1">
                    <CardTitle className="flex items-center gap-2 text-xl">
                      <div className="p-2 bg-slate-100 rounded-lg">
                        <CheckCircle2 className="w-5 h-5 text-slate-700" />
                      </div>
                      Analysis Report
                    </CardTitle>
                    <CardDescription className="text-base">
                      Instant AI fashion analysis and recommendations
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-[450px] pr-4">
                      {analysisResult ? (
                        <motion.div
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          transition={{ duration: 0.5 }}
                          className="space-y-4"
                        >
                          {analysisResult.split('\n').filter(line => line.trim()).map((line, idx) => {
                            const match = line.match(/^Line \d+: (.+)/)
                            if (match) {
                              const [, section, ...content] = match
                              const label = section.trim()
                              
                              // Special handling for Suggested outfits (Line 5)
                              if (label === 'Suggested outfits') {
                                const suggestions = content.split('|').map(s => s.trim()).filter(s => s.length > 0)
                                return (
                                  <div key={idx} className="mb-4">
                                    <h3 className="font-semibold text-slate-900 mb-2">{label}</h3>
                                    <div className="space-y-3">
                                      {suggestions.map((suggestion, sIdx) => {
                                        // Format: "Name | Description | Buy Link"
                                        const parts = suggestion.split('|').map(p => p.trim())
                                        if (parts.length === 3) {
                                          const [name, desc, link] = parts
                                          return (
                                            <div key={sIdx} className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                                              <h4 className="font-semibold text-slate-800 mb-2">{name}</h4>
                                              <p className="text-sm text-slate-600 mb-3">{desc}</p>
                                              <motion.a
                                                href={link}
                                                target="_blank"
                                                rel="noopener noreferrer sponsored"
                                                whileHover={{ scale: 1.05 }}
                                                whileTap={{ scale: 0.95 }}
                                                className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg font-medium hover:from-purple-700 hover:to-pink-700 transition-all shadow-lg cursor-pointer"
                                              >
                                                <ShoppingBag className="w-4 h-4" />
                                                Buy Now
                                              </motion.a>
                                            </div>
                                          )
                                        }
                                        return null
                                      })}
                                    </div>
                                  </div>
                                )
                              }
                              
                              const value = content.join(':').trim()
                              // Remove line number prefix if present
                              const cleanValue = value.replace(/^Line \d+:\s*/, '')
                              return (
                                <div key={idx} className="mb-4">
                                  <h3 className="font-semibold text-slate-900 mb-2">{label}</h3>
                                  <p className="text-slate-600 leading-relaxed whitespace-pre-line">{cleanValue}</p>
                                </div>
                              )
                            } else {
                              return (
                                <p key={idx} className="text-slate-600 leading-relaxed whitespace-pre-line">{line}</p>
                              )
                            }
                          })}
                        </motion.div>
                      ) : (
                        <div className="flex flex-col items-center justify-center h-72 text-slate-400 gap-4">
                          <motion.div
                            animate={{
                              rotate: [0, 360],
                              scale: [1, 1.1, 1]
                            }}
                            transition={{ 
                              duration: 2,
                              repeat: Infinity,
                              ease: "easeInOut"
                            }}
                            className="w-20 h-20 rounded-full bg-slate-100 flex items-center justify-center"
                          >
                            <ImageIcon className="w-10 h-10" />
                          </motion.div>
                          <div className="text-center">
                            <p className="font-semibold text-slate-600">Ready to Analyze</p>
                            <p className="text-sm text-slate-500">Upload an outfit photo to analyze</p>
                          </div>
                        </div>
                      )}
                    </ScrollArea>
                  </CardContent>
                </Card>
              </div>
            </motion.div>
          </TabsContent>

          {/* Style Suggestions Tab */}
          <TabsContent value="style-suggestions">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
              <Card className="border-slate-200 shadow-xl mb-6">
                <CardHeader className="space-y-1">
                  <CardTitle className="flex items-center gap-2 text-xl">
                    <div className="p-2 bg-slate-100 rounded-lg">
                      <Layers className="w-5 h-5 text-slate-700" />
                    </div>
                    AI Style Suggestions
                  </CardTitle>
                  <CardDescription className="text-base">
                    Get personalized outfit recommendations based on your preferences
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    onClick={handleGenerateStyleSuggestions}
                    className="flex items-center justify-center gap-3 p-6 bg-gradient-to-r from-slate-800 to-slate-900 rounded-2xl shadow-xl cursor-pointer"
                  >
                    <Sparkles className="w-6 h-6 text-white" />
                    <span className="text-white font-semibold text-lg">
                      {isLoadingSuggestions ? 'Generating Suggestions...' : 'Generate Style Suggestions'}
                    </span>
                    {isLoadingSuggestions && <Loader2 className="w-5 h-5 text-white animate-spin" />}
                  </motion.div>
                </CardContent>
              </Card>

              {outfitSuggestions.length > 0 && (
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {outfitSuggestions.map((suggestion, idx) => (
                    <motion.div
                      key={suggestion.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: idx * 0.1 }}
                    >
                      <Card className="border-slate-200 shadow-xl h-full hover:shadow-2xl transition-shadow">
                        <CardHeader>
                          <div className="flex items-start justify-between">
                            <CardTitle className="text-lg">{suggestion.title}</CardTitle>
                            <Badge variant="secondary">{suggestion.style}</Badge>
                          </div>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          <div className="flex items-center gap-2 text-sm text-slate-600">
                            <Palette className="w-4 h-4" />
                            <span>{suggestion.colors}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm text-slate-600">
                            <Shirt className="w-4 h-4" />
                            <span>{suggestion.occasion}</span>
                          </div>
                          <p className="text-sm text-slate-500 leading-relaxed">{suggestion.description}</p>
                          <motion.div
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                            className="mt-4"
                          >
                            <Button variant="outline" className="w-full">
                              <Heart className="w-4 h-4 mr-2" />
                              Save
                            </Button>
                          </motion.div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              )}
            </motion.div>
          </TabsContent>

          {/* Color Palette Tab */}
          <TabsContent value="color-palette">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
              <Card className="border-slate-200 shadow-xl">
                <CardHeader className="space-y-1">
                  <CardTitle className="flex items-center gap-2 text-xl">
                    <div className="p-2 bg-slate-100 rounded-lg">
                      <Palette className="w-5 h-5 text-slate-700" />
                    </div>
                    Color Palette Recommendations
                  </CardTitle>
                  <CardDescription className="text-base">
                    Discover perfect color combinations for your style
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {[
                      { name: 'Classic Navy', primary: '#1e3a5f', secondary: '#2c5282', accent: '#f7fafc', desc: 'Elegant and professional' },
                      { name: 'Warm Earth', primary: '#8b6914', secondary: '#b7791f', accent: '#faf5ff', desc: 'Natural and grounded' },
                      { name: 'Modern Gray', primary: '#2d3748', secondary: '#718096', accent: '#f7fafc', desc: 'Contemporary and sleek' },
                      { name: 'Royal Purple', primary: '#553c9a', secondary: '#805ad5', accent: '#faf5ff', desc: 'Bold and sophisticated' },
                      { name: 'Soft Pastel', primary: '#e9d8fd', secondary: '#d6bcfa', accent: '#faf5ff', desc: 'Delicate and feminine' },
                      { name: 'Bold Red', primary: '#c53030', secondary: '#e53e3e', accent: '#fff5f5', desc: 'Confident and striking' },
                      { name: 'Forest Green', primary: '#276749', secondary: '#38a169', accent: '#f0fff4', desc: 'Natural and refreshing' },
                      { name: 'Ocean Blue', primary: '#2b6cb0', secondary: '#4299e1', accent: '#ebf8ff', desc: 'Calm and trustworthy' },
                      { name: 'Sunset Orange', primary: '#c05621', secondary: '#ed8936', accent: '#fffaf0', desc: 'Energetic and vibrant' },
                      { name: 'Soft Pink', primary: '#d53f8c', secondary: '#ed64a6', accent: '#fff5f7', desc: 'Romantic and playful' },
                      { name: 'Slate Blue', primary: '#4a5568', secondary: '#718096', accent: '#f7fafc', desc: 'Versatile and timeless' },
                      { name: 'Emerald', primary: '#047857', secondary: '#10b981', accent: '#ecfdf5', desc: 'Luxurious and fresh' }
                    ].map((color, idx) => (
                      <motion.div
                        key={idx}
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.3, delay: idx * 0.05 }}
                      >
                        <Card className="border-slate-200 shadow-xl hover:shadow-2xl transition-shadow overflow-hidden">
                          <div className="h-4 flex">
                            <div className="flex-1" style={{ backgroundColor: color.primary }} />
                            <div className="flex-1" style={{ backgroundColor: color.secondary }} />
                            <div className="flex-1" style={{ backgroundColor: color.accent }} />
                          </div>
                          <CardContent className="pt-4">
                            <h3 className="font-semibold text-slate-900 mb-1">{color.name}</h3>
                            <p className="text-sm text-slate-500 mb-3">{color.desc}</p>
                            <div className="flex gap-2">
                              <div className="w-8 h-8 rounded-full border-2 border-white shadow" style={{ backgroundColor: color.primary }} />
                              <div className="w-8 h-8 rounded-full border-2 border-white shadow" style={{ backgroundColor: color.secondary }} />
                              <div className="w-8 h-8 rounded-full border-2 border-white shadow" style={{ backgroundColor: color.accent }} />
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          {/* Style Advisor Tab */}
          <TabsContent value="style-advisor">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
              <Card className="border-slate-200 shadow-xl h-[600px] flex flex-col">
                <CardHeader className="space-y-1">
                  <CardTitle className="flex items-center gap-2 text-xl">
                    <div className="p-2 bg-slate-100 rounded-lg">
                      <MessageSquare className="w-5 h-5 text-slate-700" />
                    </div>
                    AI Fashion Advisor
                  </CardTitle>
                  <CardDescription className="text-base">
                    Chat with your personal AI stylist for instant fashion advice
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col">
                  <ScrollArea className="flex-1 mb-4 pr-4">
                    <div className="space-y-4">
                      {chatMessages.map((msg, idx) => (
                        <motion.div
                          key={idx}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.3 }}
                          className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                        >
                          <div className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                            msg.role === 'user' 
                              ? 'bg-slate-900 text-white' 
                              : 'bg-slate-100 text-slate-900'
                          }`}>
                            <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </ScrollArea>
                  <div className="flex gap-2">
                    <Input
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      placeholder="Ask for fashion advice..."
                      onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                      className="flex-1"
                    />
                    <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      <Button onClick={handleSendMessage} className="bg-slate-900 hover:bg-slate-800">
                        <ArrowRight className="w-4 h-4" />
                      </Button>
                    </motion.div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          {/* Trend Explorer Tab */}
          <TabsContent value="trend-explorer">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
              <Card className="border-slate-200 shadow-xl mb-6">
                <CardHeader className="space-y-1">
                  <CardTitle className="flex items-center gap-2 text-xl">
                    <div className="p-2 bg-slate-100 rounded-lg">
                      <TrendingUp className="w-5 h-5 text-slate-700" />
                    </div>
                    Fashion Trend Explorer
                  </CardTitle>
                  <CardDescription className="text-base">
                    Discover the latest fashion trends from around the world
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-3 mb-4">
                    {['All', 'Streetwear', 'Minimalist', 'Vintage', 'Sustainable', 'Luxury'].map((category) => (
                      <motion.div
                        key={category}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        <Badge
                          variant={category === 'All' ? 'default' : 'outline'}
                          className="px-4 py-2 cursor-pointer"
                          onClick={() => handleSearchTrends(category === 'All' ? undefined : category)}
                        >
                          {category}
                        </Badge>
                      </motion.div>
                    ))}
                  </div>
                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    onClick={() => handleSearchTrends()}
                    className="flex items-center justify-center gap-3 p-6 bg-gradient-to-r from-slate-800 to-slate-900 rounded-2xl shadow-xl cursor-pointer"
                  >
                    <TrendingUp className="w-6 h-6 text-white" />
                    <span className="text-white font-semibold text-lg">
                      {isSearchingTrends ? 'Searching Trends...' : 'Search Latest Trends'}
                    </span>
                    {isSearchingTrends && <Loader2 className="w-5 h-5 text-white animate-spin" />}
                  </motion.div>
                </CardContent>
              </Card>

              {trends.length > 0 && (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {trends.map((trend, idx) => (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: idx * 0.1 }}
                    >
                      <Card className="border-slate-200 shadow-xl h-full hover:shadow-2xl transition-shadow">
                        <CardContent className="pt-6">
                          <div className="flex items-start gap-3">
                            <div className="p-2 bg-slate-100 rounded-lg">
                              <TrendingUp className="w-5 h-5 text-slate-700" />
                            </div>
                            <div className="flex-1">
                              <h3 className="font-semibold text-slate-900 mb-2">{trend.title || trend.name || 'Fashion Trend'}</h3>
                              <p className="text-sm text-slate-500 leading-relaxed">{trend.description || trend.snippet || 'Discover this trending fashion style'}</p>
                              {trend.url && (
                                <motion.a
                                  href={trend.url}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  whileHover={{ scale: 1.05 }}
                                  whileTap={{ scale: 0.95 }}
                                  className="inline-flex items-center gap-1 mt-3 text-sm text-slate-600 hover:text-slate-900"
                                >
                                  <span>Read more</span>
                                  <ChevronRight className="w-4 h-4" />
                                </motion.a>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              )}
            </motion.div>
          </TabsContent>

          {/* Preferences Tab */}
          <TabsContent value="preferences">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
              <div className="grid lg:grid-cols-2 gap-6">
                <Card className="border-slate-200 shadow-xl">
                  <CardHeader className="space-y-1">
                    <CardTitle className="flex items-center gap-2 text-xl">
                      <div className="p-2 bg-slate-100 rounded-lg">
                        <Settings className="w-5 h-5 text-slate-700" />
                      </div>
                      Style Preferences
                    </CardTitle>
                    <CardDescription className="text-base">
                      Customize your fashion preferences for personalized recommendations
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-slate-700">Style</label>
                      <Input
                        placeholder="e.g., Minimalist, Casual, Elegant"
                        value={preferences.style}
                        onChange={(e) => setPreferences({ ...preferences, style: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-slate-700">Size</label>
                      <Input
                        placeholder="e.g., M, L, 40"
                        value={preferences.size}
                        onChange={(e) => setPreferences({ ...preferences, size: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-slate-700">Colors</label>
                      <Input
                        placeholder="e.g., Navy, White, Black"
                        value={preferences.colors}
                        onChange={(e) => setPreferences({ ...preferences, colors: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-slate-700">Occasions</label>
                      <Input
                        placeholder="e.g., Work, Casual, Party"
                        value={preferences.occasions}
                        onChange={(e) => setPreferences({ ...preferences, occasions: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-slate-700">Seasons</label>
                      <Input
                        placeholder="e.g., Spring, Summer, Fall, Winter"
                        value={preferences.seasons}
                        onChange={(e) => setPreferences({ ...preferences, seasons: e.target.value })}
                      />
                    </div>
                    <motion.div
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      className="mt-6"
                    >
                      <Button className="w-full bg-slate-900 hover:bg-slate-800">
                        Save Preferences
                      </Button>
                    </motion.div>
                  </CardContent>
                </Card>

                <Card className="border-slate-200 shadow-xl">
                  <CardHeader className="space-y-1">
                    <CardTitle className="flex items-center gap-2 text-xl">
                      <div className="p-2 bg-slate-100 rounded-lg">
                        <ImageIcon className="w-5 h-5 text-slate-700" />
                      </div>
                      Generate Outfit
                    </CardTitle>
                    <CardDescription className="text-base">
                      Create AI-generated outfit visualizations based on your preferences
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {generatedImage ? (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="space-y-4"
                      >
                        <div className="aspect-square rounded-xl overflow-hidden bg-slate-100">
                          <img src={generatedImage} alt="Generated outfit" className="w-full h-full object-cover" />
                        </div>
                        <div className="flex gap-2">
                          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} className="flex-1">
                            <Button variant="outline" className="w-full">
                              <Download className="w-4 h-4 mr-2" />
                              Download
                            </Button>
                          </motion.div>
                          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} className="flex-1">
                            <Button variant="outline" className="w-full">
                              <Share2 className="w-4 h-4 mr-2" />
                              Share
                            </Button>
                          </motion.div>
                        </div>
                      </motion.div>
                    ) : (
                      <div className="flex flex-col items-center justify-center py-12 text-slate-400 gap-4">
                        <motion.div
                          animate={{
                            rotate: [0, 360],
                            scale: [1, 1.1, 1]
                          }}
                          transition={{ 
                            duration: 2,
                            repeat: Infinity,
                            ease: "easeInOut"
                          }}
                          className="w-20 h-20 rounded-full bg-slate-100 flex items-center justify-center"
                        >
                          <Shirt className="w-10 h-10" />
                        </motion.div>
                        <div className="text-center">
                          <p className="font-semibold text-slate-600">No Outfit Generated</p>
                          <p className="text-sm text-slate-500">Set your preferences and click generate</p>
                        </div>
                      </div>
                    )}
                    <motion.div
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={handleGenerateOutfit}
                      disabled={isGenerating}
                      className="flex items-center justify-center gap-3 p-6 bg-gradient-to-r from-purple-500 to-pink-600 rounded-2xl shadow-xl cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {isGenerating ? (
                        <>
                          <Loader2 className="w-6 h-6 text-white animate-spin" />
                          <span className="text-white font-semibold text-lg">Generating...</span>
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-6 h-6 text-white" />
                          <span className="text-white font-semibold text-lg">Generate Outfit</span>
                        </>
                      )}
                    </motion.div>
                  </CardContent>
                </Card>
              </div>
            </motion.div>
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <motion.footer
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.4 }}
        className="border-t bg-white/80 backdrop-blur-md mt-auto"
      >
        <div className="container mx-auto px-4 lg:px-8 py-8">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="space-y-3">
              <h3 className="font-semibold text-slate-900 flex items-center gap-2">
                <Sparkles className="w-5 h-5" />
                FashionAI
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Your personal AI fashion consultant, powered by advanced artificial intelligence for professional styling advice.
              </p>
            </div>
            <div className="space-y-3">
              <h4 className="font-semibold text-slate-900">Features</h4>
              <ul className="space-y-2 text-sm text-slate-600">
                {['AI Outfit Analysis', 'Style Suggestions', 'Color Recommendations', 'Trend Discovery'].map((feature, idx) => (
                  <motion.li
                    key={idx}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3, delay: 0.3 + idx * 0.05 }}
                    className="flex items-center gap-2"
                  >
                    <CheckCircle2 className="w-4 h-4 text-slate-500" />
                    {feature}
                  </motion.li>
                ))}
              </ul>
            </div>
            <div className="space-y-3">
              <h4 className="font-semibold text-slate-900">Contact</h4>
              <p className="text-sm text-slate-600 leading-relaxed">
                Have questions or feedback? We'd love to hear from you.
              </p>
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button variant="outline" className="border-slate-300">
                  Get in Touch
                </Button>
              </motion.div>
            </div>
          </div>
          <Separator className="my-6" />
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-sm text-slate-600">
              © 2024 FashionAI. All rights reserved.
            </p>
            <div className="flex items-center gap-6 text-sm text-slate-500">
              <a href="#" className="hover:text-slate-900 transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-slate-900 transition-colors">Terms of Service</a>
              <a href="#" className="hover:text-slate-900 transition-colors">Contact</a>
            </div>
          </div>
        </div>
      </motion.footer>
    </motion.div>
  )
}
