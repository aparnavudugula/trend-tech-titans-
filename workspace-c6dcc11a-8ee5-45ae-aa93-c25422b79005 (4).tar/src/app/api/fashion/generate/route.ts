import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'
import fs from 'fs'
import path from 'path'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { prompt } = body

    if (!prompt) {
      return NextResponse.json(
        { success: false, error: 'Prompt is required' },
        { status: 400 }
      )
    }

    // Initialize ZAI SDK
    const zai = await ZAI.create()

    // Enhance prompt for better fashion images
    const enhancedPrompt = `Professional fashion photography, ${prompt}, stylish outfit, high quality, detailed, modern fashion, clean background, professional lighting`

    // Generate outfit image
    const response = await zai.images.generations.create({
      prompt: enhancedPrompt,
      size: '1024x1024'
    })

    const imageBase64 = response.data[0]?.base64

    if (!imageBase64) {
      throw new Error('No image generated')
    }

    // Create generated-images directory if it doesn't exist
    const outputDir = path.join(process.cwd(), 'public', 'generated-outfits')
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true })
    }

    // Save the image
    const filename = `outfit_${Date.now()}.png`
    const filepath = path.join(outputDir, filename)
    const buffer = Buffer.from(imageBase64, 'base64')
    fs.writeFileSync(filepath, buffer)

    // Return the URL
    const imageUrl = `/generated-outfits/${filename}`

    return NextResponse.json({
      success: true,
      imageUrl: imageUrl
    })
  } catch (error) {
    console.error('Image generation error:', error)
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to generate outfit'
      },
      { status: 500 }
    )
  }
}
