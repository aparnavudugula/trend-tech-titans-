import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { prompt = '', preferences = {} } = body

    const zai = await ZAI.create()

    const basePrompt = `You are a professional fashion stylist. Generate 8 unique outfit suggestions.
For each suggestion, provide:
1. A catchy title (max 5 words)
2. Brief description (max 20 words)
3. Style category (one word: Minimalist, Bohemian, Streetwear, Classic, Smart Casual, Romantic, Athleisure, Vintage)
4. 3 main colors (color names only)
5. 3 suitable occasions

Format each suggestion as:
TITLE: [title]
STYLE: [style]
DESCRIPTION: [description]
COLORS: [color1], [color2], [color3]
OCCASIONS: [occasion1], [occasion2], [occasion3]

Provide diverse and creative suggestions.`

    const contextualInfo = [
      preferences.style ? `User Style Preference: ${preferences.style}` : '',
      preferences.seasons ? `Season: ${preferences.seasons}` : '',
      preferences.occasions ? `Occasion: ${preferences.occasions}` : '',
      preferences.colors ? `Preferred Colors: ${preferences.colors}` : ''
    ].filter(Boolean).join('\n')

    const systemPrompt = basePrompt + contextualInfo

    const messages = [
      {
        role: 'assistant',
        content: systemPrompt
      },
      {
        role: 'user',
        content: prompt || 'Generate 8 professional outfit suggestions'
      }
    ]

    const response = await zai.chat.completions.create({
      messages: messages,
      thinking: { type: 'disabled' }
    })

    const suggestionsText = response.choices[0]?.message?.content

    if (!suggestionsText) {
      throw new Error('No suggestions generated')
    }

    const suggestions = suggestionsText.split('\n\n').map((suggestion, index) => {
      const lines = suggestion.split('\n')
      const title = lines.find(l => l.startsWith('TITLE:'))?.replace('TITLE:', '').trim() || 'Untitled'
      const style = lines.find(l => l.startsWith('STYLE:'))?.replace('STYLE:', '').trim() || 'Casual'
      const description = lines.find(l => l.startsWith('DESCRIPTION:'))?.replace('DESCRIPTION:', '').trim() || 'Great outfit choice'
      const colorsLine = lines.find(l => l.startsWith('COLORS:'))?.replace('COLORS:', '').trim() || ''
      const colors = colorsLine.split(',').map(c => c.trim()).filter(c => c)
      const occasionsLine = lines.find(l => l.startsWith('OCCASIONS:'))?.replace('OCCASIONS:', '').trim() || ''
      const occasions = occasionsLine.split(',').map(o => o.trim()).filter(o => o)

      return {
        id: String(index + 1),
        title,
        description,
        style,
        colors: colors.slice(0, 3),
        occasions: occasions.slice(0, 3),
        imageUrl: ''
      }
    }).filter(s => s.title !== 'Untitled')

    return NextResponse.json({
      success: true,
      suggestions: suggestions
    })
  } catch (error) {
    console.error('Suggestions generation error:', error)
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to generate suggestions'
      },
      { status: 500 }
    )
  }
}
