import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Fashion AI Platform - Personalized Style Recommendations",
  description: "AI-powered fashion platform providing personalized outfit recommendations, styling advice, and trend-based insights through intelligent content generation and analysis.",
  keywords: ["Fashion AI", "Style Recommendations", "Outfit Analyzer", "Personal Styling", "AI Fashion Advisor", "Fashion Trends", "Next.js", "TypeScript"],
  authors: [{ name: "Fashion AI Platform" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "Fashion AI Platform",
    description: "Your personal AI fashion advisor for personalized styling and outfit recommendations",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Fashion AI Platform",
    description: "AI-powered fashion platform for personalized styling",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
