'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { toast } from '@/hooks/use-toast'
import { motion } from 'framer-motion'
import { 
  User, 
  Lock, 
  Mail, 
  Eye, 
  EyeOff,
  Sparkles,
  ArrowRight,
  LogIn
} from 'lucide-react'

export default function LoginPage() {
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  })

  const gradients = [
    'from-purple-400 via-pink-500 to-rose-500',
    'from-blue-400 via-cyan-500 to-teal-500',
    'from-orange-400 via-pink-500 to-purple-500',
    'from-green-400 via-teal-500 to-blue-500',
    'from-pink-400 via-rose-500 to-orange-500',
    'from-indigo-400 via-purple-500 to-pink-500'
  ]

  const [bgColor, setBgColor] = useState(0)

  const containerVariants = {
    hidden: { opacity: 0 },
    show: { opacity: 1 },
  }

  const cardVariants = {
    hidden: { 
      opacity: 0, 
      y: 50,
      scale: 0.9,
      rotate: -2
    },
    show: { 
      opacity: 1, 
      y: 0,
      scale: 1,
      rotate: 0,
      transition: {
        duration: 0.6,
        ease: [0.43, 0.13, 0.23, 1]
      }
    }
  }

  const inputVariants = {
    focus: {
      scale: 1.02,
      borderColor: 'rgba(124, 58, 237, 0.5)',
      transition: { duration: 0.2 }
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    setTimeout(() => {
      setIsLoading(false)
      toast({
        title: 'Welcome Back!',
        description: 'You have successfully logged in.',
        variant: 'default',
      })
      window.location.href = '/'
    }, 1500)
  }

  return (
    <motion.div
      initial="hidden"
      animate="show"
      variants={containerVariants}
      transition={{ duration: 0.6 }}
      className="min-h-screen flex items-center justify-center overflow-hidden relative"
    >
      {/* Animated Background */}
      <div className="absolute inset-0 -z-10">
        <motion.div
          className={`w-full h-full bg-gradient-to-br ${gradients[bgColor]} transition-all duration-[10000ms] ease-in-out`}
          animate={{
            opacity: [0.6, 0.8, 0.6],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        <div className="absolute inset-0 bg-slate-50/95 backdrop-blur-sm" />
      </div>

      {/* Floating Elements */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute bg-white/10 rounded-full blur-3xl"
            style={{
              width: Math.random() * 200 + 100,
              height: Math.random() * 200 + 100,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`
            }}
            animate={{
              y: [0, -30, 0],
              x: [0, 20, 0],
              scale: [1, 1.2, 1],
            }}
            transition={{
              duration: 4 + i,
              repeat: Infinity,
              ease: "easeInOut",
              delay: i * 0.5
            }}
          />
        ))}
      </div>

      <motion.div
        variants={cardVariants}
        initial="hidden"
        animate="show"
        className="relative z-10 w-full max-w-md px-4"
      >
        <Card className="border-slate-200 shadow-2xl backdrop-blur-xl bg-white/95">
          <CardHeader className="space-y-2 text-center pb-6">
            <motion.div
              animate={{ 
                rotate: [0, 5, -5, 0],
                scale: [1, 1.1, 1]
              }}
              transition={{ 
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="w-16 h-16 rounded-2xl bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center mx-auto shadow-xl"
            >
              <LogIn className="w-8 h-8 text-white" />
            </motion.div>
            <CardTitle className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-slate-900 to-purple-900">
              Welcome Back
            </CardTitle>
            <CardDescription className="text-base text-slate-600">
              Sign in to continue to your FashionAI account
            </CardDescription>
          </CardHeader>

          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-5">
              <motion.div variants={inputVariants} whileFocus="focus">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                    <Mail className="w-4 h-4" />
                    Email Address
                  </label>
                  <div className="relative">
                    <Input
                      type="email"
                      placeholder="you@example.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="pl-11 h-12 border-slate-300 focus:border-purple-500"
                      required
                    />
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  </div>
                </div>
              </motion.div>

              <motion.div variants={inputVariants} whileFocus="focus">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                    <Lock className="w-4 h-4" />
                    Password
                  </label>
                  <div className="relative">
                    <Input
                      type={showPassword ? "text" : "password"}
                      placeholder="Enter your password"
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      className="pl-11 pr-11 h-12 border-slate-300 focus:border-purple-500"
                      required
                    />
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    <motion.button
                      type="button"
                      whileTap={{ scale: 0.9 }}
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors"
                    >
                      {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </motion.button>
                  </div>
                </div>
              </motion.div>

              <div className="flex items-center justify-between text-sm">
                <label className="flex items-center gap-2 cursor-pointer text-slate-600 hover:text-slate-900 transition-colors">
                  <input type="checkbox" className="rounded border-slate-300" />
                  <span>Remember me</span>
                </label>
                <Link href="/forgot-password" className="text-purple-600 hover:text-purple-700 font-medium transition-colors">
                  Forgot password?
                </Link>
              </div>

              <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                <Button
                  type="submit"
                  disabled={isLoading}
                  className="w-full bg-gradient-to-r from-slate-800 to-slate-900 hover:from-slate-700 hover:to-slate-800 h-12 text-base shadow-lg"
                >
                  {isLoading ? (
                    <>
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                      >
                        <Sparkles className="w-5 h-5 mr-2" />
                      </motion.div>
                      Signing in...
                    </>
                  ) : (
                    <>
                      <span className="mr-2">Sign In</span>
                      <ArrowRight className="w-5 h-5" />
                    </>
                  )}
                </Button>
              </motion.div>
            </form>

            <div className="relative mt-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-200" />
              </div>
              <span className="relative bg-white px-3 text-sm text-slate-500 font-medium">
                Or continue with
              </span>
            </div>

            <div className="grid grid-cols-3 gap-3 mt-6">
              {['Google', 'Apple', 'GitHub'].map((provider, idx) => (
                <motion.button
                  key={idx}
                  type="button"
                  whileHover={{ scale: 1.05, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                  className="flex items-center justify-center gap-2 px-4 py-3 border-2 border-slate-200 rounded-xl hover:border-slate-400 hover:bg-slate-50 transition-all bg-white"
                >
                  <div className="w-5 h-5 rounded-full bg-gradient-to-br from-slate-100 to-slate-200" />
                  <span className="text-sm font-medium text-slate-700">{provider}</span>
                </motion.button>
              ))}
            </div>

            <p className="text-center text-sm text-slate-600 mt-6">
              Don't have an account?{' '}
              <Link href="/signup" className="text-purple-600 hover:text-purple-700 font-semibold transition-colors">
                Create one now
              </Link>
            </p>
          </CardContent>
        </Card>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-6 text-center"
        >
          <Link 
            href="/"
            className="inline-flex items-center gap-2 px-4 py-2 text-slate-600 hover:text-slate-900 transition-colors"
          >
            <ArrowRight className="w-4 h-4 rotate-180" />
            <span className="font-medium">Back to Home</span>
          </Link>
        </motion.div>
      </motion.div>
    </motion.div>
  )
}
