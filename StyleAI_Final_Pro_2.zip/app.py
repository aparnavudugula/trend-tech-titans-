
from flask import Flask, render_template, request, jsonify
import os
import cv2
import numpy as np

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
os.makedirs('uploads', exist_ok=True)

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/upload', methods=['POST'])
def upload():
    file = request.files['image']
    gender = request.form['gender']

    path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(path)

    skintone = detect_skin_tone(path)
    profile = get_skin_profile(skintone)
    recommendation = generate_recommendation(profile["name"], gender)

    return jsonify({
        "profile": profile,
        "recommendation": recommendation
    })

def detect_skin_tone(image_path):
    image = cv2.imread(image_path)
    avg_color = np.mean(image, axis=(0,1))

    if avg_color[0] > 180:
        return "Fair"
    elif avg_color[0] > 140:
        return "Medium"
    elif avg_color[0] > 100:
        return "Olive"
    else:
        return "Deep"

def get_skin_profile(skintone):

    profiles = {

        "Fair": {
            "name": "Ivory Glow",
            "colors": ["#F8EDEB", "#E3D5CA", "#D5BDAF"],
            "outfits": {
                "Casual Shirt": "https://www.amazon.in/s?k=light+blue+shirt",
                "Formal Blazer": "https://www.myntra.com/blazer",
                "White Shoes": "https://www.amazon.in/s?k=white+shoes"
            }
        },

        "Medium": {
            "name": "Golden Radiance",
            "colors": ["#E6BE8A", "#C58940", "#8D5524"],
            "outfits": {
                "Navy Shirt": "https://www.amazon.in/s?k=navy+shirt",
                "Formal Suit": "https://www.myntra.com/suit",
                "Brown Shoes": "https://www.amazon.in/s?k=brown+shoes"
            }
        },

        "Olive": {
            "name": "Honey Bronze",
            "colors": ["#C68642", "#A0522D", "#6F4E37"],
            "outfits": {
                "Beige T-Shirt": "https://www.amazon.in/s?k=beige+tshirt",
                "Formal Shirt": "https://www.myntra.com/formal-shirt",
                "Tan Shoes": "https://www.amazon.in/s?k=tan+shoes"
            }
        },

        "Deep": {
            "name": "Cocoa Elegance",
            "colors": ["#5C4033", "#3B2F2F", "#2C1B18"],
            "outfits": {
                "Yellow Shirt": "https://www.amazon.in/s?k=yellow+shirt",
                "Premium Formal": "https://www.myntra.com/formal-wear",
                "Black Shoes": "https://www.amazon.in/s?k=black+shoes"
            }
        }
    }

    return profiles.get(skintone)

def generate_recommendation(skin_name, gender):
    return f"""✨ Personalized Style Guide for {gender}

Skin Profile: {skin_name}

• Casual: Smart T-shirt with fitted jeans
• Formal: Structured blazer with tailored trousers
• Party: Statement jacket with boots
• Accessories: Watch, sunglasses, minimal jewelry

These colors enhance your natural tone and elevate confidence.
"""

if __name__ == "__main__":
    app.run(debug=True)
