import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get('image') as File

    if (!file) {
      return NextResponse.json(
        { success: false, error: 'No image file provided' },
        { status: 400 }
      )
    }

    // Convert file to base64
    const bytes = await file.arrayBuffer()
    const buffer = Buffer.from(bytes)
    const base64Image = buffer.toString('base64')
    const mimeType = file.type || 'image/jpeg'

    // Initialize ZAI SDK
    const zai = await ZAI.create()

    // Ultra-quick analysis with 5 sections including suggested outfits with direct product links
    const analysisPromise = zai.chat.completions.createVision({
      messages: [
        {
          role: 'system',
          content: 'Always return exactly 5 lines. Line 1: Style. Line 2: Colors. Line 3: Rating 1-10. Line 4: Two improvement tips. Line 5: Suggested outfits with 3 items. For each suggested outfit, provide Name, Description, and the direct product purchase URL (not redirect URL). Use these exact e-commerce sites and generate actual product URLs that go directly to product pages: Myntra (https://www.myntra.com), Flipkart (https://www.flipkart.com), Amazon (https://www.amazon.in), Ajio (https://www.ajio.com), Myntra Fashion (https://www.myntrafashion.com), Tata Cliq (https://www.tatacliq.com). For Myntra, format as /p/[product-id] where product-id should be a realistic ID. For Amazon, use /dp/[ASIN]. For Flipkart, use /[product-category]/[product-name]. For Ajio, use /product/[product-id]. Ensure all URLs start with https:// and are complete direct product links. Make sure the Name and Description match the product exactly.'
        },
        {
          role: 'user',
          content: [
            {
              type: 'text',
              text: 'Analyze this outfit'
            },
            {
              type: 'image_url',
              image_url: {
                url: `data:${mimeType};base64,${base64Image}`
              }
            }
          ]
        }
      ],
      max_tokens: 150
    })

    const response = await analysisPromise

    const analysis = response.choices[0]?.message?.content

    if (!analysis) {
      throw new Error('No analysis generated')
    }

    return NextResponse.json({
      success: true,
      analysis: analysis
    })
  } catch (error) {
    console.error('Outfit analysis error:', error)
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to analyze outfit'
      },
      { status: 500 }
    )
  }
}
